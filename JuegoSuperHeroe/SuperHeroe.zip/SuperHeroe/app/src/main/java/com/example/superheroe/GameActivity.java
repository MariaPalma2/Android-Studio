package com.example.superheroe;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.FrameLayout;
import androidx.appcompat.app.AppCompatActivity;
import android.media.MediaPlayer;

public class GameActivity extends AppCompatActivity {

    private GameView gameView;
    private MediaPlayer mediaPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game); // Establece el layout con el LinearLayout

        // Inicializar la música de fondo
        mediaPlayer = MediaPlayer.create(this, R.raw.musica);
        mediaPlayer.setLooping(true); // Repetir en bucle
        mediaPlayer.start(); // Iniciar la música

        // Asegurar que el Layout donde se añadirá GameView existe
        FrameLayout layout = findViewById(R.id.gameLayout);

        layout.post(() -> {
            gameView = new GameView(this); // Instancia una sola vez
            layout.addView(gameView);
        });
    }

    public void gameOver() {
        // Aquí puedes manejar lo que pasa cuando el juego termina, por ejemplo, ir a una pantalla de Game Over
        Intent intent = new Intent(GameActivity.this, GameOverActivity.class);
        startActivity(intent);
        finish();  // Finaliza la actividad actual para que el jugador no pueda volver a ella
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Detener y liberar la música cuando la actividad se cierre
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }
}
