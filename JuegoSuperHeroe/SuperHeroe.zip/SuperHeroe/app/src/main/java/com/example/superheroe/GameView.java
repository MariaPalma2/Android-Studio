package com.example.superheroe;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import com.example.superheroe.modelos.ObjetoQueCae;
import com.example.superheroe.modelos.SuperHero;

import java.util.ArrayList;
import java.util.List;

public class GameView extends SurfaceView implements SurfaceHolder.Callback {
    private GameThread gameThread;
    private SuperHero superHero;
    private Handler handler;
    private Bitmap background;
    private List<ObjetoQueCae> objetos; // Lista de objetos que caen

    public GameView(Context context) {
        super(context);
        getHolder().addCallback(this);
        gameThread = new GameThread(getHolder(), this);
        handler = new Handler(Looper.getMainLooper());

        // Cargar imagen de fondo
        background = BitmapFactory.decodeResource(getResources(), R.drawable.fondo_juego);
        objetos = new ArrayList<>(); // Inicializar la lista de objetos que caen
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        superHero = new SuperHero(getContext(), getWidth(), getHeight());
        objetos.add(new ObjetoQueCae(getContext(), getWidth())); // Añadir un objeto que cae al inicio
        gameThread.setRunning(true);
        gameThread.start();
        Log.d("GameView", "Juego iniciado correctamente");
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {}

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        boolean retry = true;
        while (retry) {
            try {
                gameThread.setRunning(false);
                gameThread.join();
                retry = false;
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        Log.d("GameView", "Juego detenido correctamente");
    }

    public void update() {
        superHero.update();

        // Actualizamos los objetos que caen
        for (ObjetoQueCae objeto : objetos) {
            objeto.actualizar();

            // Detectar si el superhéroe ha chocado con el objeto
            if (superHero.haSidoGolpeado(objeto.getX(), objeto.getY(), objeto.getAncho(), objeto.getAlto())) {
                gameWon();
                return; // Detener el juego si se gana
            }
        }

        // Verificar si el superhéroe ha chocado con la pared
        if (superHero.haChocadoConPared()) {
            gameOver();
        }
    }
    private void gameWon() {
        gameThread.setRunning(false);

        handler.post(() -> {
            Paint paint = new Paint();
            Canvas canvas = getHolder().lockCanvas();
            if (canvas != null) {
                // Fondo negro (puedes cambiar el color de fondo si lo prefieres)
                canvas.drawColor(Color.BLACK);

                // Cargar la imagen que dice "Has ganado"
                Bitmap wonImage = BitmapFactory.decodeResource(getResources(), R.drawable.ganar); // Nombre de la imagen en drawable

                // Calcular la posición para centrar la imagen en la pantalla
                int xPos = (getWidth() - wonImage.getWidth()) / 2; // Centrado horizontal
                int yPos = (getHeight() - wonImage.getHeight()) / 2; // Centrado vertical

                // Dibujar la imagen
                canvas.drawBitmap(wonImage, xPos, yPos, null);

                // Liberar el canvas
                getHolder().unlockCanvasAndPost(canvas);
            }

            // Esperar un poco y luego salir del juego
            postDelayed(() -> {
                if (getContext() instanceof Activity) {
                    ((Activity) getContext()).finish();
                }
                System.exit(0);
            }, 2000); // Espera de 2 segundos antes de finalizar
        });
    }


    // Manejar el Game Over
    private void gameOver() {
        gameThread.setRunning(false);

        handler.post(() -> {
            // Iniciar la actividad de Game Over
            Intent intent = new Intent(getContext(), GameOverActivity.class);
            getContext().startActivity(intent);

            // Opcional: Finalizar la actividad actual para que el usuario no pueda volver atrás
            if (getContext() instanceof Activity) {
                ((Activity) getContext()).finish();
            }
        });
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            float touchX = event.getX();
            if (touchX < getWidth() / 2) {
                superHero.moveLeft();
            } else {
                superHero.moveRight();
            }
        }
        return true;
    }

    @Override
    public void draw(Canvas canvas) {
        super.draw(canvas);
        if (canvas != null) {
            canvas.drawBitmap(Bitmap.createScaledBitmap(background, getWidth(), getHeight(), true), 0, 0, null);
            superHero.draw(canvas);

            // Dibujar los objetos que caen
            for (ObjetoQueCae objeto : objetos) {
                objeto.dibujar(canvas);
            }

            // Mostrar mensaje de puntuación o instrucciones (opcional)
            Paint paint = new Paint();
            paint.setColor(Color.WHITE);
            paint.setTextSize(50);
            canvas.drawText("Evita la pared!", 50, 100, paint);
        }
    }

    public void recycle() {
        return;
    }
}
