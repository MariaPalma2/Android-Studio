package com.example.superheroe;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Establecemos el layout
    }

    // Método llamado cuando el usuario hace clic en el botón "Empezar Juego"
    public void startGame(View view) {
        // Inicia la actividad GameActivity
        Intent intent = new Intent(MainActivity.this, GameActivity.class);
        startActivity(intent);
        finish(); // Terminamos MainActivity para que no se pueda volver
    }

    // Método llamado cuando el usuario hace clic en el botón "Salir"
    public void exitGame(View view) {
        // Finaliza la aplicación
        finish();
        System.exit(0); // Termina la aplicación
    }
}
