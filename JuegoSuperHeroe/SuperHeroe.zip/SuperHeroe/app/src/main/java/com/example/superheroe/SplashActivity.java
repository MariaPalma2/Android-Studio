package com.example.superheroe;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.animation.ObjectAnimator;
import android.view.animation.DecelerateInterpolator;

public class SplashActivity extends Activity {

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable goToMain = new Runnable() {
        @Override
        public void run() {
            // Después de 3 segundos, se inicia la MainActivity
            startActivity(new Intent(SplashActivity.this, MainActivity.class));
            finish(); // Evita que el usuario regrese al SplashActivity
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash); // Este es el archivo XML para el SplashActivity

        ImageView imgLogo = findViewById(R.id.imgLogo);
        ProgressBar progressBar = findViewById(R.id.progressBar);

        // Animación de la imagen (cae desde la parte superior)
        ObjectAnimator animator = ObjectAnimator.ofFloat(imgLogo, "translationY", 0f);
        animator.setDuration(1500); // Duración de la animación de la imagen
        animator.setInterpolator(new DecelerateInterpolator());
        animator.start();

        // Establece un retraso de 3 segundos y luego pasa a la MainActivity
        handler.postDelayed(goToMain, 3000);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(goToMain); // Evita posibles fugas de memoria
    }
}
