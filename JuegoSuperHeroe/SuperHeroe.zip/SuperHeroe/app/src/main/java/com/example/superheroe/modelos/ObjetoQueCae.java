package com.example.superheroe.modelos;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import com.example.superheroe.R;

public class ObjetoQueCae {
    private Bitmap bitmap;
    private int x, y;
    private int velocidad;
    private int objectWidth = 100; // Ancho del objeto (ajustable)
    private int objectHeight = 100; // Alto del objeto (ajustable)

    public ObjetoQueCae(Context context, int screenWidth) {
        // Cargar la imagen original del objeto
        bitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.objeto2);

        // Escalar la imagen al tamaño deseado
        bitmap = Bitmap.createScaledBitmap(bitmap, objectWidth, objectHeight, false);

        // Inicializar la posición de caída (en la parte superior de la pantalla)
        x = (int) (Math.random() * (screenWidth - objectWidth)); // Posición aleatoria en el eje X
        y = 0; // Empieza desde la parte superior de la pantalla

        // Velocidad de caída
        velocidad = 10;
    }

    public void actualizar() {
        y += velocidad; // El objeto cae hacia abajo

        // Si el objeto sale de la pantalla, lo volvemos a colocar en la parte superior
        if (y > 1000) { // Asumir un valor para la altura de la pantalla, ajústalo a tu necesidad
            y = 0;
            // Volver a colocar en una posición aleatoria en el eje X
            x = (int) (Math.random() * (1000 - objectWidth)); // Ajustar a la anchura de la pantalla
        }
    }

    public void dibujar(Canvas canvas) {
        // Dibujar el objeto redimensionado
        canvas.drawBitmap(bitmap, x, y, null);
    }

    // Métodos para obtener las coordenadas y dimensiones del objeto
    public int getX() { return x; }
    public int getY() { return y; }
    public int getAncho() { return objectWidth; }
    public int getAlto() { return objectHeight; }
}
