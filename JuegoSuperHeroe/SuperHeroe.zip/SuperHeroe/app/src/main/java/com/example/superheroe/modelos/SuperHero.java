package com.example.superheroe.modelos;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;

import com.example.superheroe.R;

public class SuperHero {
    private Bitmap bitmap;
    private int x, y;
    private int screenWidth, screenHeight;
    private int speedX = 30; // Velocidad de movimiento lateral
    private int floatOffset = 0;
    private boolean movingUp = true;

    public SuperHero(Context context, int screenWidth, int screenHeight) {
        this.screenWidth = screenWidth;
        this.screenHeight = screenHeight;
        bitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.superhero);

        // Inicializar la posición del superhéroe en el centro de la pantalla
        x = screenWidth / 2 - bitmap.getWidth() / 2;
        y = screenHeight / 2 - bitmap.getHeight() / 2;
    }

    public void update() {
        // Lógica para el efecto de flotación
        if (movingUp) {
            floatOffset -= 2;
            if (floatOffset <= -10) movingUp = false;
        } else {
            floatOffset += 2;
            if (floatOffset >= 10) movingUp = true;
        }
    }

    public void moveLeft() {
        x -= speedX;
        if (x < 0) {
            x = 0;
        }
    }

    public void moveRight() {
        x += speedX;
        if (x + bitmap.getWidth() > screenWidth) {
            x = screenWidth - bitmap.getWidth();
        }
    }
    public boolean haSidoGolpeado(int objetoX, int objetoY, int objetoAncho, int objetoAlto) {
        return x < objetoX + objetoAncho &&
                x + bitmap.getWidth() > objetoX &&
                y < objetoY + objetoAlto &&
                y + bitmap.getHeight() > objetoY;
    }


    public void draw(Canvas canvas) {
        canvas.drawBitmap(bitmap, x, y + floatOffset, null);
    }

    public boolean haChocadoConPared() {
        return x < 20 || x + bitmap.getWidth() >= screenWidth;
    }
}